from Chain import *

if __name__ == '__main__':
    app = GoodChain()
    app.run()     